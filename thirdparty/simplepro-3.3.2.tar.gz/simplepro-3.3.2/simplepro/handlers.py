import os
import struct
import rsa

'''
so_file = open(os.path.join(os.path.dirname(__file__), 'simplepro.so'), 'rb')
buffer = so_file.read(2)
r, = struct.unpack('h', buffer)
buffer = so_file.read(r)
pri = buffer
strs = bytearray()
while True:
    temp = so_file.read(4)
    if len(temp) == 0:
        so_file.close()
        break
    size, = struct.unpack('i', temp)
    d = so_file.read(size)
    privkey = rsa.PrivateKey.load_pkcs1(pri)
    strs.extend(rsa.decrypt(d, privkey))
print(strs.decode(encoding='utf8'))
with open('data.py','wb') as f:
    f.write(strs)
'''
#exec(compile(strs.decode(encoding='utf8'), '<string>', 'exec'))


import datetime
import json
import os
import re
import struct
import time
import traceback

import requests
import rsa as rsa
from django.conf import settings
from django.conf.urls import url
from django.contrib import messages
from django.contrib.auth.admin import GroupAdmin
from django.core.paginator import Paginator
from django.db.models import Model, Q
from django.forms import ModelForm
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.urls import reverse
from django.utils.html import format_html
from simplepro import conf, forms
from .bawa import views as bawa_views

from simplepro.utils import LazyEncoder, has_permission, write, get_model_info, search_placeholder, get_custom_button, \
    get_menus, write_obj, get_model_headers

URL_CACHE = {}

import base64
import copy

cache_d = None

lic_file = os.path.join(os.getcwd(), 'simplepro.lic')

from django.forms import fields, models as form_models
from django.db import models


def O0O0OOO0OOO0OO0O0(reload=False):
    try:

        if not os.path.exists(lic_file):
            return False
        global cache_d
        if reload:
            cache_d = None

        if cache_d:
            return cache_d
        f = open(lic_file, 'rb')
        buffer = f.read()
        a, = struct.unpack('h', buffer[0:2])
        b, = struct.unpack('h', buffer[2:4])
        d1 = buffer[4:a + 4]
        d2 = base64.b64decode(buffer[a + 4:a + 4 + b])

        # 文件被改动移动过

        # decode
        pk = rsa.PrivateKey.load_pkcs1(d2)
        text = rsa.decrypt(d1, pk).decode()  # 注意，这里如果结果是bytes类型，就需要进行decode()转化为str
        d = json.loads(text)
        cache_d = d
    except Exception as e:
        pass
    return d


def OO0O0OO0OOO0OO0O0(request):
    return True
    try:
        d = O0O0OOO0OOO0OO0O0()
        # 校验失效时间和设备ID
        end = d.get('end_date').split(' ')[0]
        end_date = datetime.datetime.strptime(end, '%Y-%m-%d')
        now = datetime.datetime.now()
        if now > end_date:
            request.msg = '您的激活码已于<strong>{}<strong>过期，请重新购买！'.format(end_date)
            return False
        device_id = d.get('device_id')
        if str(conf.get_device_id()) != str(device_id):
            request.msg = '激活码和设备ID不匹配，请重新激活！<div>您的设备ID:{}</div><div>激活的设备ID:{}</div>'.format(conf.get_device_id(),
                                                                                               device_id)
            return False
        return True
    except Exception as e:
        # raise e
        pass
    return False


def pre_process(request, view_func):
    # 如果不是admin的url，不拦截
    admin_url = reverse('admin:index')
    if hasattr(view_func, 'admin_site'):
        # 如果是admin 直接过，普通用户才做权限处理
        if request.user and not request.user.is_superuser:
            request.menus = get_menus(request, view_func.admin_site)

    if not hasattr(view_func, 'model_admin') or request.path.find(admin_url) == -1:
        return None

    # TODO 如果admin中有 list_edit 就不处理，用simpleui渲染
    # if hasattr(view_func.model_admin, 'list_editable'):
    #     list_editable = getattr(view_func.model_admin, 'list_editable')
    #     if list_editable or len(list_editable) != 0:
    #         return

    # 刷新的参数移除_，防止报错
    if '_' in request.GET:
        if hasattr(request.GET, '_mutable'):
            request.GET._mutable = True
            del request.GET['_']

    if not OO0O0OO0OOO0OO0O0(request):
        return process_active(request)

    # 如果是is_popup 不处理
    if '_popup' in request.GET or not request.user.is_authenticated:
        pass
    elif 'model_admin' in view_func.__dict__:

        # 把admin直接加入到request，让后续的自定义标签一类，可以直接访问admin
        request.model_admin = view_func.model_admin

        if isinstance(view_func.model_admin, GroupAdmin):
            class Media:
                js = ('admin/group/js/group.js',)

            view_func.model_admin.Media = Media
            view_func.model_admin.list_display = ('id', 'name')
            view_func.model_admin.list_per_page = 10
        path = request.path

        opts = view_func.model_admin.opts
        key = 'admin:{}_{}_changelist'.format(opts.app_label, opts.model_name)
        # model_admin

        temp = URL_CACHE.get(path)
        if temp:
            return process_list(request, temp)

        elif reverse(key) == path:
            # 加入缓存提示性能
            URL_CACHE[request.path] = view_func.model_admin
            return process_list(request, view_func.model_admin)


def custom_action(request, model_admin):
    """处理自定义按钮的动作"""
    """
        默认，执行成功就会返回成功，失败就失败，如果用户自己有返回数据，就用用户返回的
    """

    rs = {
        'state': True,
        'msg': '操作成功！',
    }
    try:
        post = request.POST

        all = post.get('all')
        ids = post.get('ids')
        key = post.get('key')

        """
        action: "custom_action"
        all: 0
        ids: "102,100"
        key: "make_copy"""
        model = model_admin.model
        queryset = model.objects.get_queryset()

        # 处理默认查询条件
        if all == '0':
            d = {}
            if ids:
                d[get_model_pk(model) + '__in'] = ids.split(',')

            queryset = queryset.filter(**d)

        fun = getattr(model_admin, key)
        result = fun(request, queryset)

        # 允许自己返回参数，必须是词典才行
        if result and isinstance(result, dict):
            rs = result

        # 如果result 是None的时候，就读取自定义的message
        if result is None:
            rs = {
                'state': True,
                'messages': []
            }
            ms = messages.get_messages(request)
            for item in ms:
                rs['messages'].append({
                    'msg': item.message,
                    'tag': item.level_tag,
                })

    except Exception as e:
        rs = {
            'state': False,
            'msg': e.args[0]
        }
        traceback.print_exc()

    return HttpResponse(json.dumps(rs, cls=LazyEncoder), content_type='application/json')


def process_list(request, model_admin):
    if '_editor' in request.GET:
        return process_editor(request)

    action = request.POST.get('action')

    actions = {
        'list': list_data,
        'delete': delete_data,
        # 自定义按钮
        'custom_action': custom_action
    }

    if action and action not in actions:
        pass
    elif action:
        # 自定义filter做映射
        filter_mappers = {}
        changelist = model_admin.get_changelist_instance(request)
        if changelist.has_filters:
            for spec in changelist.filter_specs:
                param_name = None
                if hasattr(spec, 'field_path'):
                    param_name = spec.field_path
                elif hasattr(spec, 'parameter_name'):
                    param_name = spec.parameter_name
                elif hasattr(spec, 'lookup_kwarg'):
                    param_name = spec.lookup_kwarg
                if param_name:
                    filter_mappers[param_name] = spec
        model_admin.filter_mappers = filter_mappers
        try:
            return actions[action](request, model_admin)
        except Exception as e:
            traceback.print_exc()
            return write(data=None, msg=e.args[0], state=False)

    else:

        # 响应搜索参数

        changelist = model_admin.get_changelist_instance(request)
        model_admin.has_filters = changelist.has_filters
        model_admin.filter_specs = changelist.filter_specs
        searchModel = []
        if model_admin.has_filters:
            for spec in model_admin.filter_specs:
                # parameter_name
                if hasattr(spec, 'field_path'):
                    searchModel.append(spec.field_path)
                elif hasattr(spec, 'parameter_name'):
                    searchModel.append(spec.parameter_name)
                elif hasattr(spec, 'lookup_kwarg'):
                    searchModel.append(spec.lookup_kwarg)

        # 解析Media
        media = None

        if hasattr(model_admin, 'Media'):
            m = model_admin.Media
            media = {}
            if hasattr(m, 'js'):
                new_array = []
                # 移除导入导出插件的js
                jss = getattr(m, 'js')

                for js in jss:
                    if not js.endswith('import_export/action_formats.js'):
                        new_array.append(js)

                media['js'] = new_array
            if hasattr(m, 'css'):
                media['css'] = getattr(m, 'css')

        # 获取3个权限
        # has_delete_permission
        # has_add_permission
        # has_change_permission

        # 如果有messages，就获取，然后在页面进行显示

        mlist = []
        ms = messages.get_messages(request)
        for item in ms:
            mlist.append({
                'msg': str(item.message),
                'tag': str(item.level_tag),
            })
        # 获取post参数，
        return render(request, 'admin/results/list.html', {
            'request': request,
            'cl': model_admin,
            'opts': model_admin.opts,
            'media': media,
            'title': model_admin.model._meta.verbose_name_plural,
            'model': model_admin.model,
            'searchModels': json.dumps(searchModel, cls=LazyEncoder),
            'has_delete_permission': has_permission(request, model_admin, 'delete'),
            'has_add_permission': has_permission(request, model_admin, 'add'),
            'has_change_permission': has_permission(request, model_admin, 'change'),
            'mlist': json.dumps(mlist),
            'has_summaries': hasattr(model_admin, 'get_summaries'),
            'has_editor': get_has_editor(model_admin),
        })


def get_has_editor(admin):
    return len(admin.list_editable) != 0


def delete_data(request, model_admin):
    """
    删除数据
    :param request:
    :return:
    """

    # 拼凑queryset
    model = model_admin.model
    queryset = model.objects.get_queryset()
    ids = request.POST.get('ids')

    rs = {
        'state': True,
        'msg': '删除成功！'
    }

    if ids:
        ids = ids.split(',')
        query = {}

        query['pk__in'] = ids
        queryset = queryset.filter(**query)

    # elif request.POST.get('all') == 1:
    #     queryset = queryset.all()
    #     pass

    try:
        # TODO 需要处理model的信号

        if hasattr(model_admin, 'delete_queryset'):
            getattr(model_admin, 'delete_queryset')(request, queryset)
            queryset.delete()
            # 返回其他的 就不处理
    except Exception as e:
        rs = {
            'state': False,
            'msg': e.args[0]
        }
    return write(rs)


def get_model_pk(model):
    return 'pk'
    # return model._meta.pk.name


def list_data(request, model_admin):
    """
    获取list数据
    :param request:
    :param model_admin:
    :return:
    """
    """
        admin 中字段设置
        fields_options={
            'id':{
                'fixed':'left',
                'width':'100px',
                'algin':'center'
            }
        }
    """
    table = {}

    current_page = request.POST.get('current_page')
    if current_page:
        current_page = int(current_page)
    else:
        current_page = 1
    # 页数由admin中读取，页码，由前台传入
    formatter, choices = get_model_info(model_admin, request)

    # values_fields,fun_fields,headers 缓存
    values_fields, fun_fields, headers = get_model_headers(model_admin, request)

    # queryset是从admin中获取
    queryset = model_admin.get_queryset(request)
    # if not queryset:
    # raise Exception("queryset can't be None")
    # queryset = model.objects.get_queryset()

    filters = request.POST.get('filters')
    query = {

    }

    # 处理q
    search = request.POST.get('search')
    if search and search != '':
        q = Q()
        search_fields = model_admin.search_fields
        for s in search_fields:
            q = q | Q(**{s + "__icontains": search})
        try:
            queryset = queryset.filter(q)
        except Exception as e:
            traceback.print_exc()
            raise e

    if filters:
        filters = json.loads(filters)
        for key in filters:
            # 映射处理
            if key in model_admin.filter_mappers:
                # 判断类类型，相关字段不处理
                filter = model_admin.filter_mappers[key]
                filter.used_parameters = filters

                queryset = filter.queryset(request, queryset)
            else:

                # TODO 耗时，需要进行优化

                # 如果是日期字段要进行格式化
                # 匹配TZ，没有就匹配常规
                val = filters.get(key)
                # +8
                if re.fullmatch(r'\d{4}\-\d{2}-\d{2}\s\d{2}\:\d{2}\:\d{2}\s\d{2}\:\d{2}', val):
                    t = re.match(r'\d{4}\-\d{2}-\d{2}\s\d{2}\:\d{2}\:\d{2}', val)
                    if t:
                        temp = t[0]
                        date = datetime.datetime.strptime(temp, '%Y-%m-%d %H:%M:%S')
                        val = date + datetime.timedelta(hours=8)
                elif re.fullmatch(r'\d{4}\-\d{2}-\d{2}\s\d{2}\:\d{2}\:\d{2}', val):
                    # 正常
                    val = datetime.datetime.strptime(val, '%Y-%m-%d %H:%M:%S')
                elif re.fullmatch(r'\d{4}\-\d{2}-\d{2}', val):
                    # 年月日
                    val = datetime.datetime.strptime(val, '%Y-%m-%d')
                elif re.fullmatch(r'\d{3}\-\d{2}-\d{2}', val):
                    # 时分秒
                    val = time.strptime(val, ' %H:%M:%S')
                query[key] = val

    qs = queryset.filter(**query)
    sum_qs = copy.deepcopy(queryset)

    # 排序在admin中 get_queryset 已经进行默认处理
    if 'order_by' in request.POST:
        v = request.POST.get('order_by')
        if v and v != '' and v != 'null':
            qs = qs.order_by(v)

    if hasattr(qs, 'ordered') and not qs.ordered:
        # 处理默认排序
        qs = qs.order_by('-pk')

    page_size = model_admin.list_per_page
    if 'page_size' in request.POST:
        r = int(request.POST.get('page_size'))
        if r != 0:
            page_size = r

    page = Paginator(qs, page_size)
    if current_page > page.num_pages:
        current_page = page.num_pages
    rs = page.page(current_page)
    object_list = rs.object_list

    # 读取值的时候需要处理特殊的 choices

    rows = []
    list_display_links = ()
    if hasattr(model_admin, 'list_display_links'):
        list_display_links = model_admin.list_display_links

    if not list_display_links:
        # 防止报错
        list_display_links = ()

    for i in object_list:
        row = {}
        for v in values_fields:
            key = v + '_choices'
            if key in choices:
                value = getattr(i, v)
                mappers = choices[key]
                if value in mappers:
                    value = mappers.get(value)
            elif v in choices:
                value = getattr(i, v)
                mappers = choices[v]
                if value in mappers:
                    value = mappers.get(value)
            else:
                value = getattr(i, v)
                if value and issubclass(value.__class__, models.fields.files.ImageFieldFile):
                    value = format_html(
                        '<a href="{}" target="_blank"><img src="{}" alt="{}" style="max-height:100%;max-width:100%"></a>',
                        value.url, value.url, value)

            # gender_choices

            # 如果admin有formatter调用进行格式化
            if formatter:
                value = formatter(i, v, value)
            elif issubclass(value.__class__, Model):
                # 如果model有 __unicode__ 方法，优先使用
                if hasattr(value, '__unicode__'):
                    value = value.__unicode__()
                else:
                    value = str(value)

            # 有formatter 就不处理 link
            if v in list_display_links and not formatter:
                opts = model_admin.opts
                url = reverse('admin:{}_{}_changelist'.format(opts.app_label, opts.model_name))
                pk_field = get_model_pk(model_admin.model)
                _id = getattr(i, pk_field)
                url = url + '{}/change'.format(_id)
                value = format_html('<a href="{}">{}</a>', url, str(value))

            row[v] = value

        for f in fun_fields:
            try:
                if f == '__str__':
                    if hasattr(model_admin.model, '__str__'):
                        value = getattr(model_admin.model, '__str__')(i)
                    else:
                        value = None

                elif hasattr(model_admin, f):
                    value = getattr(model_admin, f).__call__(i)
                elif f == 'pk':
                    value = getattr(i, f)
                else:
                    value = getattr(model_admin.model, f).__call__(i)
                if formatter:
                    value = formatter(i, f, value)
                row[f] = value
            except Exception as e:
                traceback.print_exc()

                if hasattr(f, ' __qualname__'):
                    raise Exception(
                        e.args[0] + '\n call {} error. 调用自定义方法出错，请检查模型中的{}方法'.format(f.__qualname__, f.__qualname__))
                else:
                    raise e
        # ID字段必须返回，因为删改都是通过id作为唯一键
        pk_field = get_model_pk(model_admin.model)
        row['_id'] = getattr(i, pk_field)
        rows.append(row)

    # list_display 默认为对象的str
    # list_per_page 默认为10

    # 根据需要的字段进行返回

    table['headers'] = headers

    # 处理统计
    if hasattr(model_admin, 'get_summaries'):
        table['summaries'] = model_admin.get_summaries(request, sum_qs)

    # 第二页开始就不返回headers
    initialized = request.POST.get('initialized')
    if initialized != 'true':
        actions_show = True
        if hasattr(model_admin, 'actions_show'):
            actions_show = getattr(model_admin, 'actions_show') != False
        # table['headers'] = headers
        table['exts'] = {
            'showId': 'id' in values_fields,
            'actions_show': actions_show,
            'showSearch': len(model_admin.search_fields) > 0,
            'search_placeholder': search_placeholder(model_admin)
        }

        # 获取自定义按钮
        # TODO 自定义按钮加入权限判断
        table['custom_button'] = get_custom_button(request, model_admin)

        # 响应搜索参数
        # has_filters
        # filter_specs
        # model_admin.get_changelist_instance(request).filter_specs
        # model_admin.get_changelist_instance(request).filter_specs

    # 如果admin中有get_results方法，将使用get_results的返回的数据
    if hasattr(model_admin, 'get_results'):
        rows = model_admin.get_results(rows, request, queryset)

    table['rows'] = rows
    table['paginator'] = {
        'page_size': page_size,
        'count': page.count,
        'page_count': page.num_pages

    }

    return write(table)


def process_active(request):
    # 如果是ajax就返回错误信息，是页面就返回页面
    rules = [reverse('admin:index'), reverse('admin:login'), reverse('admin:logout')]
    path = request.path

    post = request.POST
    action = post.get('action')
    if action:
        return write(None, 'Simple Pro未激活，请联系客服人员进行激活！', False)
    elif path not in rules:
        return render(request, 'admin/active.html', {
            'device_id': conf.get_device_id()
        })


def process_lic(request):
    # 调用服务器接口，获取激活信息，如果激活成功，就覆盖本地文件
    device_id = conf.get_device_id()
    active_code = request.POST.get('active_code')

    url = conf.get_server_url() + '/active'
    r = requests.post(url, data={
        'device_id': device_id,
        'active_code': active_code
    })

    if r.status_code == 200:
        data = r.json()
        if data.get('state') is True:
            # 获取根目录，写入激活文件
            # 内容需要混淆写入

            f = open(lic_file, 'wb')

            # d1 = bytes(data.get('license'), encoding='utf8')
            d1 = base64.b64decode(data.get('license'))
            d2 = base64.b64encode(bytes(data.get('private_key'), encoding='utf8'))

            f.write(struct.pack('h', len(d1)))
            f.write(struct.pack('h', len(d2)))

            f.write(d1)
            f.write(d2)

            f.close()
            O0O0OOO0OOO0OO0O0(True)

            print('写入激活文件，位置：{}'.format(lic_file))
            # pass
        return write_obj(data)
    return write({}, 'error', False)


def process_info(request):
    return render(request, 'admin/active.html', {
        'page_size': OO0O0OO0OOO0OO0O0(request),
        'data': O0O0OOO0OOO0OO0O0(),
        'device_id': conf.get_device_id()
    })


def process_package(request):
    r = requests.get("{}/package".format(conf.get_server_url()))
    return write(r.json())


def pre_reload(request):
    if hasattr(request, 'reload'):
        O0O0OOO0OOO0OO0O0(True)


def process_editor(request):
    pk = request.GET.get('_pk')

    admin = request.model_admin
    model = admin.model
    ins = model.objects.get(pk=pk)
    data = None

    class GeneralForm(ModelForm):

        class Meta:
            model = admin.model
            fields = admin.list_editable

    if request.method == 'GET':
        form = GeneralForm(instance=ins)
    else:
        form = GeneralForm(data=request.POST, instance=ins)
        if form.is_valid():
            obj = form.save()
            data = {
                'state': True,
                'msg': '修改成功！'
            }
            # 调用admin的信号
            admin.save_form(request, form, True)
            # 调用save model
            admin.save_model(request, obj, form, True)

        else:
            data = {
                'state': False,
                'msg': '校验失败，请根据提示修改！'
            }
    # http://localhost:8000/demo/employe/?_editor=1&_pk=4
    if data:
        data = json.dumps(data)

    # 每个字段获取类型
    types = {}

    for name in form.fields:
        field = form.fields.get(name)
        if issubclass(type(field), fields.ChoiceField) or issubclass(type(field),
                                                                     form_models.ChoiceField) or issubclass(type(field),
                                                                                                            form_models.ModelChoiceField):
            types[name] = 'select'
        elif issubclass(type(field), fields.BooleanField):
            types[name] = 'boolean'
        elif issubclass(type(field), fields.DateField):
            types[name] = 'date'
        elif issubclass(type(field), fields.TimeField):
            types[name] = 'time'
        elif issubclass(type(field), fields.DateTimeField):
            types[name] = 'datetime'

    return render(request, 'admin/results/editor.html', {
        'form': form,
        'types': json.dumps(types),
        'data': data
    })


def process_models(request):
    rs = []
    session = request.session
    if '_menus' in session:
        temp = session.get('_menus')

        temp_obj = json.loads(temp)

        for item in temp_obj:
            rs.append({
                'name': item.get('name'),
                'icon': item.get('icon'),
                'url': item.get('url')
            })

            if 'models' in item:
                ms = item.get('models')
                for sub in ms:
                    rs.append({
                        'name': sub.get('name'),
                        'icon': sub.get('icon'),
                        'url': sub.get('url')
                    })

    response = HttpResponse(json.dumps(rs), content_type='application/json')
    # response['Access-Control-Allow-Methods'] = '*'
    response['Access-Control-Allow-Origin'] = '*'
    response['Access-Control-Allow-Credentials'] = 'true'
    return response


def bawa_page(request):
    # 使用拦截器 拦截所有的bawa页面，作用是 session问题
    if 'bawa/data' in request.path:
        return bawa_views.get_data(request)
    elif 'bawa/save' in request.path:
        return bawa_views.save(request)
    # 如果项目内用默认的图表url
    elif '.json' in request.path:
        return redirect(settings.STATIC_URL + request.path.replace('/sp', '/admin'))
    else:
        return render(request, 'admin/bawa/render.html')

def process_request(request, path):
    if path.endswith('simplepro/active/'):
        return process_lic(request)
    elif path.endswith('simplepro/package/'):
        return process_package(request)
    elif path.endswith('simplepro/info/'):
        return process_info(request)
    elif 'models/models.json' in path:
        return process_models(request)

    elif 'sp/bawa/' in path:
        return bawa_page(request)


def process_view(request, view):
    return pre_process(request, view)
  
def done(arg1):
    print(arg1)
    pass