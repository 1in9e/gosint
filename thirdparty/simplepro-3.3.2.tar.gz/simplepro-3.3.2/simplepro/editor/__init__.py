import lzma,base64
exec(lzma.decompress(base64.b64decode(b'/Td6WFoAAATm1rRGAAAAABzfRCEftvN9AQAAAAAEWVo=')))