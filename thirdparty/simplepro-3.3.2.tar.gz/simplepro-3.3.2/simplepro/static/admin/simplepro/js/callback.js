window.addEventListener('load', __ => {
    if (window.js_callback) {
        window.js_callback();
    }
});
