new Vue({
    el: "#app",
    data: {
        form: {
        }
    }, created: function () {
        this.form = window.data;
    }
})